package 网络爬虫;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 爬虫：从王者荣耀官网爬取图片
 * 爬虫需要依赖一个jar包，百度搜索Maven，搜索jsoup，点击最新版本，点击homepath，点击下载
 * 下载完成复制到该项目下及包里，然后鼠标右键bulidPath，add to buildPath
 * @author 朱胜利
 *
 */
public class 爬虫 {
	static String url="https://pvp.qq.com/web201605/herolist.shtml";
	 static String path = "d://img/";
	public static void getImgs(String  url) {
		/*
		 * 这个方法是根据网络地址获取对应网络地址上的图片
		 * url是字符串类型所以是String类型
		 */
		try {//获取对应网站上的html代码
			Document document=Jsoup.connect(url).userAgent("Mozilla(compatible;MSIE 9.0;Window NT 6.1;Tri)").get();
			//从html代码中获取图片的ul标签
			Elements selectUL=document.select("[class=herolist clearfix]");
			//在ul标签中寻找li标签
			Elements selectLI=selectUL.select("li");
			//for循环遍历所有的li标签，获取详细页地址，以及头像图片
			for(Element e:selectLI) {//forEach循环，后者代表一个集合，e代表每次从中获取的元素
				//找到详情页的地址
				String heroURL=e.select("a").attr("href");
				//获取英雄名称text（）获取标签中的文本内容
				String heroName=e.select("a").text();
				//拼接详情页的地址
				String detailURL="https://pvp.qq.com/web201605/"+heroURL;
				//获取详情页的html代码
				Document doc=Jsoup.connect(detailURL).userAgent("Mozilla(compatible;MSIE 9.0;Window NT 6.1;Tri)").get();
			//找到显示背景的div标签
				Elements div=doc.select("[class=zk-con1 zk-con]");
				//获取显示的背景
				String bg=div.attr("style");
				//拆分字符串：拆分英雄图片的地址
				//subString(起始位置，终止位置)
				String heroImgUrl=bg.substring(16,bg.length()-11);
				
				//规定图片你下载的地址
				String uri=path+heroName+".jpg";
				//下载图片
				download("http:"+heroImgUrl,uri);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String args[]) {
		getImgs(url);
		long start=System.currentTimeMillis();
		long end=System.currentTimeMillis();
		System.out.println("图片下载完毕耗时："+(end+start)/1000.0);
	}
public static void download(String imgUrl,String path) {
	//构建URL链接
	try {
		URL url=new URL(imgUrl);//URL类，先创建一个对象
		DataInputStream dataInputStream=new DataInputStream(url.openStream());
		FileOutputStream outputStream=new FileOutputStream(path);
		ByteArrayOutputStream output=new ByteArrayOutputStream();//创建一个对象
		byte[] buffer=new byte[1024];
		int length=0;
		while((length=dataInputStream.read(buffer))!=-1) {
			output.write(buffer,0,length);
		}
		outputStream.write(output.toByteArray());
		outputStream.close();
		dataInputStream.close();
		output.close();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
}
}